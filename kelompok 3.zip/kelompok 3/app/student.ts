export interface Student {
    _id: string;
    first: string;
    last: string;
    email: string;
    name: string;
    age: number;
}
